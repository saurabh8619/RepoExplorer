//
//  CityFloDemoApp.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//

import SwiftUI

@main
struct CityFloDemoApp: App {

    var body: some Scene {
        WindowGroup {
            SearchView()
        }
    }
}
