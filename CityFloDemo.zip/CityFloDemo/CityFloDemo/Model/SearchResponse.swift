//
//  SearchResponse.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import Foundation

struct SearchResponse: Codable {
    let items: [Repo]
}
