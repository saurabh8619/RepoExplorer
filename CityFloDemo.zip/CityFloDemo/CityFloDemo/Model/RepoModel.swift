//
//  RepoModel.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//import Foundation
import Foundation

struct Repo: Codable, Identifiable {

    let id: Int
    let name: String
    let fullName: String
    let description: String?
    let stargazersCount: Int
    let forksCount: Int
    let language: String?
    let htmlURL: String

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case description
        case language

        case fullName = "full_name"
        case stargazersCount = "stargazers_count"
        case forksCount = "forks_count"
        case htmlURL = "html_url"
    }
}
