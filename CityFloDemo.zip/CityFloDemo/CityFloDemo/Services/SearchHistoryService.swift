//
//  SearchHistoryService.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import Foundation

protocol SearchHistoryServiceProtocol {
    func save(query: String)
    func fetch() -> [String]
}

final class SearchHistoryService:
SearchHistoryServiceProtocol {

    private let key =
    "recent_searches"

    func save(query: String) {

        var history = fetch()

        history.removeAll {
            $0.lowercased()
            ==
            query.lowercased()
        }

        history.insert(
            query,
            at: 0
        )

        history =
        Array(history.prefix(10))

        UserDefaults.standard.set(
            history,
            forKey: key
        )
    }

    func fetch() -> [String] {

        UserDefaults.standard
            .stringArray(
                forKey: key
            ) ?? []
    }
}
