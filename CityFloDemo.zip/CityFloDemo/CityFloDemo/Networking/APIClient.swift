//
//  APIClient.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import Foundation

protocol APIClientProtocol {
    func searchRepositories(
        query: String
    ) async throws -> [Repo]
}

final class APIClient: APIClientProtocol {

    func searchRepositories(
        query: String
    ) async throws -> [Repo] {

        let encodedQuery =
        query.addingPercentEncoding(
            withAllowedCharacters: .urlQueryAllowed
        ) ?? query

        let urlString =
        "https://api.github.com/search/repositories?q=\(encodedQuery)"

        guard let url =
        URL(string: urlString) else {
            throw URLError(.badURL)
        }

        let (data, response) =
        try await URLSession.shared.data(
            from: url
        )

        guard let httpResponse =
        response as? HTTPURLResponse,
        200...299 ~= httpResponse.statusCode
        else {
            throw URLError(
                .badServerResponse
            )
        }

        let result =
        try JSONDecoder().decode(
            SearchResponse.self,
            from: data
        )

        return result.items
    }
}
