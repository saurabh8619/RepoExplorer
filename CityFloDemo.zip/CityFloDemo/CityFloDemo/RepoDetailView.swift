//
//  RepoDetailView.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import SwiftUI

struct RepoDetailView: View {

    let repo: Repo

    var body: some View {

        Form {

            Section("Repository") {

                Text(repo.name)
                    .font(.title2)

                Text(
                    repo.description ??
                    "No Description"
                )
            }

            Section("Statistics") {

                HStack {

                    Text("Stars")

                    Spacer()

                    Text(
                        "\(repo.stargazersCount)"
                    )
                }

                HStack {

                    Text("Forks")

                    Spacer()

                    Text(
                        "\(repo.forksCount)"
                    )
                }

                HStack {

                    Text("Language")

                    Spacer()

                    Text(
                        repo.language ?? "-"
                    )
                }
            }

            Section {

                Link(
                    "Open on GitHub",
                    destination:
                    URL(
                        string:
                        repo.htmlURL
                    )!
                )
            }
        }
        .navigationTitle(repo.name)
    }
}
