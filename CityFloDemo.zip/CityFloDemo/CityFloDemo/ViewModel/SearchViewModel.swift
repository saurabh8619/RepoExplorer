//
//  SearchViewModel.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import Foundation
import Observation

@Observable
@MainActor
final class SearchViewModel {

    var query = ""
    var repositories: [Repo] = []
    var recentSearches: [String] = []
    var isLoading = false
    var errorMessage: String?

    private let apiClient: APIClientProtocol
    private let historyService: SearchHistoryServiceProtocol

    private var searchTask: Task<Void, Never>?

    init(
        apiClient: APIClientProtocol = APIClient(),
        historyService: SearchHistoryServiceProtocol = SearchHistoryService()
    ) {
        self.apiClient = apiClient
        self.historyService = historyService

        recentSearches = historyService.fetch()
    }

    func search() {

        guard !query.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty else {

            repositories = []
            return
        }

        searchTask?.cancel()

        searchTask = Task {

            do {

                isLoading = true

                try await Task.sleep(
                    for: .milliseconds(500)
                )

                try Task.checkCancellation()

                let repos =
                try await apiClient
                    .searchRepositories(
                        query: query
                    )

                try Task.checkCancellation()

                repositories = repos

                historyService.save(
                    query: query
                )

                recentSearches =
                    historyService.fetch()

                isLoading = false

            } catch is CancellationError {

            } catch {

                errorMessage =
                    error.localizedDescription

                isLoading = false
            }
        }
    }

    func searchFromHistory(
        _ selectedQuery: String
    ) {

        query = selectedQuery
        search()
    }
}
