//
//  SearchView.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import SwiftUI

struct SearchView: View {

    @State
    private var vm =
        SearchViewModel()

    var body: some View {

        NavigationStack {

            Group {

                if vm.repositories.isEmpty &&
                    vm.recentSearches.isEmpty &&
                    !vm.isLoading {

                    ContentUnavailableView(
                        "Discover GitHub Repositories",
                        systemImage:
                        "magnifyingglass",
                        description:
                        Text(
                            "Search for SwiftUI, Firebase, Alamofire and more."
                        )
                    )

                } else {

                    List {

                        if !vm.recentSearches.isEmpty {

                            Section(
                                "Recent Searches"
                            ) {

                                ForEach(
                                    vm.recentSearches,
                                    id: \.self
                                ) { item in

                                    Button {

                                        vm.searchFromHistory(
                                            item
                                        )

                                    } label: {

                                        HStack {

                                            Image(
                                                systemName:
                                                "clock.arrow.circlepath"
                                            )

                                            Text(item)
                                        }
                                    }
                                }
                            }
                        }

                        Section(
                            "Repositories"
                        ) {

                            ForEach(
                                vm.repositories
                            ) { repo in

                                NavigationLink {

                                    RepoDetailView(
                                        repo: repo
                                    )

                                } label: {

                                    RepoRowView(
                                        repo: repo
                                    )
                                }
                            }
                        }
                    }
                }
            }
            .overlay {

                if vm.isLoading {

                    ProgressView()
                }
            }
            .navigationTitle(
                "Repo Explorer"
            )
            .searchable(
                text: $vm.query,
                prompt: "Search repositories"
            )
            .searchSuggestions {

                ForEach(
                    ["swiftui", "firebase", "alamofire", "ios"],
                    id: \.self
                ) { item in

                    Text(item)
                        .searchCompletion(item)
                }
            }
            .onChange(
                of: vm.query
            ) {
                vm.search()
            }            .onChange(
                of: vm.query
            ) {

                vm.search()
            }
            .alert(
                "Error",
                isPresented: Binding(
                    get: {
                        vm.errorMessage != nil
                    },
                    set: { _ in
                        vm.errorMessage = nil
                    }
                )
            ) {

                Button("OK") { }

            } message: {

                Text(
                    vm.errorMessage ?? ""
                )
            }
        }
    }
}
