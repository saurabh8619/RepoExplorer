//
//  RepoRowView.swift
//  CityFloDemo
//
//  Created by saurabh mishra on 17/06/26.
//
import SwiftUI

struct RepoRowView: View {

    let repo: Repo

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 8
        ) {

            Text(repo.fullName)
                .font(.headline)

            if let description =
                repo.description {

                Text(description)
                    .font(.subheadline)
                    .foregroundStyle(
                        .secondary
                    )
                    .lineLimit(2)
            }

            HStack {

                Label(
                    "\(repo.stargazersCount)",
                    systemImage: "star.fill"
                )

                Spacer()

                Text(
                    repo.language ??
                    "Unknown"
                )
            }
            .font(.caption)
        }
        .padding(.vertical, 4)
    }
}
